# LotsizeHemmati Bot

A Telegram bot for capital and lot size management using Python.

## Features
- Membership check in Telegram channel
- Currency pair selection
- Capital input and lot size calculation
- Live price fetch
- Trading psychology tips

## Setup
1. Copy `.env.sample` to `.env` and set your `BOT_TOKEN` and `CHANNEL_ID`.
2. Install dependencies:
